<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Beheer Evenementen</h1>
    <a href="<?php echo e(route('admin.events.create')); ?>" class="btn btn-primary mb-4">Nieuw Evenement Toevoegen</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Titel</th>
                <th style="width: 120px;">Datum</th>
                <th>Tijd</th>
                <th>Locatie</th>
                <th>Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($event->title); ?></td>
                <td class="text-nowrap"><?php echo e($event->date->format('d-m-Y')); ?></td>
                <td><?php echo e($event->time); ?></td>
                <td><?php echo e($event->location); ?></td>
                <td>
                    <div style="display: flex; gap: 5px;">
                        <a href="<?php echo e(route('admin.events.edit', $event)); ?>" class="btn btn-edit btn-sm">Bewerken</a>
                        <form action="<?php echo e(route('admin.events.destroy', $event)); ?>" method="POST" style="margin: 0;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-delete btn-sm" style="color: #fff; border: none; border-radius: 25px; padding: 12px 24px; font-weight: 600; transition: background-color 0.2s;" onclick="return confirm('Weet je zeker dat je dit evenement wilt verwijderen?')">Verwijderen</button>
                        </form>
                    </div>
                </td>


            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ticketsystem\resources\views/admin/events/index.blade.php ENDPATH**/ ?>