<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Aankomende Evenementen</h1>
    <h2>Welkom op de evenementenpagina van Anwar Agrich</h2>
    <div class="row">
        <?php $__currentLoopData = $upcomingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <div class="card ticket-card" style="height: 100%;">
                <div class="card-img-top">
                    <img src="<?php echo e($event->imageurl); ?>" alt="<?php echo e($event->title); ?>" class="img-fluid">
                </div>
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?php echo e($event->title); ?></h5>
                    <p class="card-text"><strong>Datum:</strong> <?php echo e($event->date->format('d-m-Y')); ?></p>
                    <p class="card-text"><strong>Tijd:</strong> <?php echo e(\Carbon\Carbon::parse($event->time)->format('H:i')); ?></p>
                    <p class="card-text"><strong>Locatie:</strong> <?php echo e($event->location); ?></p>
                    <p class="card-text"><strong>Beschrijving:</strong> <?php echo e($event->description); ?></p>
                    <div class="mt-auto">
                        <a href="<?php echo e(route('event.show', $event)); ?>" class="btn btn-primary">Bestel Tickets</a>
                    </div>
                </div>
            </div>
        </div>





        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ticketsystem\resources\views/home.blade.php ENDPATH**/ ?>