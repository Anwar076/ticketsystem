<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Evenement Bewerken</h1>
    <form action="<?php echo e(route('admin.events.update', $event)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Titel</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo e($event->title); ?>" required>
        </div>
        <div class="form-group">
            <label for="date">Datum</label>
            <input type="date" class="form-control" id="date" name="date" value="<?php echo e($event->date); ?>" required>
        </div>
        <div class="form-group">
            <label for="time">Tijd</label>
            <input type="time" class="form-control" id="time" name="time" value="<?php echo e($event->time); ?>" required>
        </div>
        <div class="form-group">
            <label for="location">Locatie</label>
            <input type="text" class="form-control" id="location" name="location" value="<?php echo e($event->location); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Beschrijving</label>
            <textarea class="form-control" id="description" name="description"><?php echo e($event->description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="imageurl">Afbeelding URL:</label>
            <input type="text" name="imageurl" id="imageurl" class="form-control" value="<?php echo e($event->imageurl); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Opslaan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ticketsystem\resources\views/admin/events/edit.blade.php ENDPATH**/ ?>